 <!-- Page Footer-->
          <footer class="main-footer" style="margin-top: 300px;">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>Sistema de Gerenciamento e Controle de Salão - SENAC &copy; <?php echo date('Y'); ?></p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Os Sobreviventes</p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"> </script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/Chart.min.js"></script>
    <script src="js/charts-home.js"></script>
    <script src="js/front.js"></script>
    
  </body>
</html>