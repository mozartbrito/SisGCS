<!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
          <img src="img/LOGO.png" style="width: 80%">
           <!--  <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4">Mark Stephen</h1>
              <p>Web Designer</p>
            </div> -->
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Menu</span>
          <ul class="list-unstyled">
            <li class="active"> <a href="index.php"><i class="icon-home"></i>Principal</a></li>
            <li > <a href="formulario.php"><i class="icon-padnote"></i>Formulários</a></li>
            <li > <a href="tabelas.php"><i class="icon-grid"></i>Tabelas</a></li>


            <li><a href="#dashvariants" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Menu Suspenso </a>
              <ul id="dashvariants" class="collapse list-unstyled">
                <li><a href="#">Exemplo</a></li>
                <li><a href="#">Exemplo</a></li>
                <li><a href="#">Exemplo</a></li>
                <li><a href="#">Exemplo</a></li>
              </ul>
            </li>


           
          </ul>
        </nav>