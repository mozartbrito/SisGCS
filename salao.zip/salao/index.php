<?php include 'template/header.php'; ?>
<?php include 'template/menu.php'; ?>

<div class="content-inner">
  <!-- Page Header-->
  <header class="page-header">
    <div class="container-fluid">
      <h2 class="no-margin-bottom">Principal</h2>
    </div>
  </header>

  <section class="dashboard-counts no-padding-bottom">
    <div class="container-fluid">
      Conteúdo aqui
    </div>
  </section>
  <!-- Client Section-->
<?php include 'template/footer.php'; ?>

         